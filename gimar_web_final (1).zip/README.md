# Gimar Pastelería y Repostería

Sitio web oficial de **Gimar Pastelería y Repostería**, desarrollado con HTML y CSS.

## Secciones
- Sobre Nosotros
- Galería de Productos
- Momentos Dulces
- Contáctanos

## Cómo publicar en GitHub Pages
1. Sube este repositorio a tu cuenta de GitHub.
2. Ve a **Settings > Pages**.
3. Selecciona la rama `main` y la carpeta `/root`.
4. Guarda los cambios y tu página estará en línea.

---
© 2025 Gimar Pastelería y Repostería
